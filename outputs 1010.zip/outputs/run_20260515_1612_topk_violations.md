| Rank | Feature | Taxonomy class | Global viol. | Per-query viol. | Δ reduction | Global n | Per-query n | Pattern |
|---:|:---|:---|---:|---:|---:|---:|---:|:---|
| 1 | HvyAlcoholConsump | monotonic_down | 1.000 | 0.000 | +1.000 | 115 | 0 | suppressed_entirely |
| 2 | CholCheck | monotonic_up | 0.989 | 0.000 | +0.989 | 270 | 0 | suppressed_entirely |
| 3 | AnyHealthcare | monotonic_up | 0.960 | 0.000 | +0.960 | 75 | 0 | suppressed_entirely |
| 4 | NoDocbcCost | monotonic_down | 0.958 | 0.000 | +0.958 | 24 | 6 | redirected |
| 5 | Education | monotonic_up | 0.787 | 0.000 | +0.787 | 47 | 51 | redirected |
| 6 | Fruits | monotonic_up | 0.667 | 0.000 | +0.667 | 45 | 21 | redirected |
| 7 | Smoker | monotonic_down | 0.618 | 0.077 | +0.541 | 34 | 13 | partial_redirect |
| 8 | MentHlth | monotonic_down | 0.564 | 0.041 | +0.523 | 55 | 49 | partial_redirect |
| 9 | Veggies | monotonic_up | 0.444 | 0.000 | +0.444 | 45 | 14 | redirected |
| 10 | PhysActivity | monotonic_up | 0.262 | 0.000 | +0.262 | 42 | 59 | redirected |
| 11 | PhysHlth | monotonic_down | 0.217 | 0.000 | +0.217 | 46 | 79 | redirected |
| 12 | Income | monotonic_up | 0.173 | 0.000 | +0.173 | 75 | 130 | redirected |
| 13 | GenHlth | monotonic_down | 0.084 | 0.009 | +0.075 | 155 | 233 | partial_redirect |
| 14 | HighChol | monotonic_down | 0.066 | 0.006 | +0.060 | 121 | 178 | partial_redirect |
| 15 | Age | immutable | 0.000 | 0.000 | +0.000 | 0 | 0 | no_changes |
| 16 | BMI | bidirectional | 0.000 | 0.000 | +0.000 | 507 | 705 | no_global_violations |
| 17 | DiffWalk | conditional | 0.000 | 0.000 | +0.000 | 0 | 0 | no_changes |
| 18 | HeartDiseaseorAttack | immutable | 0.000 | 0.000 | +0.000 | 0 | 0 | no_changes |
| 19 | Sex | immutable | 0.000 | 0.000 | +0.000 | 0 | 0 | no_changes |
| 20 | Stroke | immutable | 0.000 | 0.000 | +0.000 | 0 | 0 | no_changes |
| 21 | HighBP | monotonic_down | 0.006 | 0.007 | -0.001 | 166 | 269 | partial_redirect |